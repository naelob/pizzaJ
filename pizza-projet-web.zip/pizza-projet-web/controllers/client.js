const {client} = require("./../db/database");

async function register_client(){

}
async function login_client(){

}
module.exports = {
    register_client,
    login_client
}