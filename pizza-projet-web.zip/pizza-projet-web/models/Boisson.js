const db = require('./../db');

module.exports = Boisson;
