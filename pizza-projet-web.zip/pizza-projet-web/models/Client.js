const db = require('./../db');


module.exports = Client;