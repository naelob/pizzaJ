const db = require('./../db');


module.exports = Ingredient;
