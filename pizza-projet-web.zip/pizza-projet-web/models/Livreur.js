const db = require('./../db');

module.exports = Livreur;
