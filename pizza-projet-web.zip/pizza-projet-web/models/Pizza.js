const db = require('./../db');


module.exports = Pizza;
